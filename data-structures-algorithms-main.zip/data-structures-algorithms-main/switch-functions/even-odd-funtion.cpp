#include <iostream>
using namespace std;

bool isEven(int a) {
    if(a&1) {
        return true;
    }
    else {
        return false;
    }
}