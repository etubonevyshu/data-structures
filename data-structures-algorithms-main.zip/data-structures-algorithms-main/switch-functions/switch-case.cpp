#include <iostream>
using namespace std;

int main() {
    int num;
    num = 2;

    switch (num)
    {
    case 1: cout<<"first case";
            break;
    
    case 2: cout<<"second case\n";
            break;
            
    default:
        break;
    }
}