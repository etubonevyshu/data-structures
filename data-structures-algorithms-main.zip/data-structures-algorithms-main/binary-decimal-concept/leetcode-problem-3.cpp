#include<cmath>
class Solution {
public:
    bool isPowerOfTwo(int n) {
        for(int i=0; i<31; i++) {
            if(n == pow(2,i));
            return true;
        }
    }
};