#include<iostream>
using namespace std;

int main() {
    int a,b;
    cin>>a>>b;

    if(a>b) {
        cout<<"A is greater"<<endl;
    }
    else {
        cout<<"B is greater"<<endl;
    }
return 0;
}