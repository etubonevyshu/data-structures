#include <iostream>
using namespace std;

int main() {
    int cel = 100;
    int f,i = 0;

    while(i<cel) {
        f = (9/5)*cel + 32;
        cout<<f;
    }
    return 0;
}