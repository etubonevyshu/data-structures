#include <iostream>
using namespace std;

int main() {
    int a;
    a = cin.get(); //provides ascii value of given int
    cout<<a<<endl;
    return 0;
}