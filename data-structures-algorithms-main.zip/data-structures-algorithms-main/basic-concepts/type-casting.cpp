#include<iostream>
using namespace std;

int main() {
    int a = 'd';
    cout<<a<<endl;

    char b = 105;
    cout<<b<<endl;

    return 0;
}