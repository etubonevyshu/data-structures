#include<iostream>
using namespace std;

int main() {
    int a = 123;
    cout<<a<<endl;

    char b = 'n';
    cout<<b<<endl;

    bool c = 1;
    cout<<c<<endl;

    int size = sizeof(a);
    cout<<"Size of a is : "<<size<<endl;

    char ch1 = 123456;
    cout<<ch1<<endl;

    unsigned int d = -112; //always positive integers
    cout<<d<<endl;

    return 0;

}