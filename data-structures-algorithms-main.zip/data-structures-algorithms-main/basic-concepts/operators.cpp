#include <iostream>
using namespace std;

int main() {
    int b = 2/5;
    cout<<b<<endl;

    float a = 2.0/5;
    cout<<a<<endl;
    return 0;
}