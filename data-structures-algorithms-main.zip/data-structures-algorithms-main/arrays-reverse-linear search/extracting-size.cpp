#include <iostream>
using namespace std;

int main() {
    int fifth[10];
    int size = sizeof(fifth)/sizeof(int);
    cout<<size<<endl;
}