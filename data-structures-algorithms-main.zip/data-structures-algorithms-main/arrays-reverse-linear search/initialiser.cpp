#include <iostream>
using namespace std;

int main() {
    int arr[5] = {[0 ... 4] = 5};

}