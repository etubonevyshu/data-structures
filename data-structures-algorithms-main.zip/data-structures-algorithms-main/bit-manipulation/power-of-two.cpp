#include <iostream>
using namespace std;

int pow(int x) {
    return !x&(x-1);
}