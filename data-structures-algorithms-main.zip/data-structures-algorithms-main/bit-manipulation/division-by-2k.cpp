#include <iostream>
using namespace std;

int divide(int x,int k) {
    return x>>k;
}