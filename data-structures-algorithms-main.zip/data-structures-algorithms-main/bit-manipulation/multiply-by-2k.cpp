#include <iostream>
using namespace std;

int multiply(int x,int k) {
    return x<<k;
}