#include <iostream>
using namespace std;

int main() {
    int x;
    if(x&1) cout<<"odd number";
    return 0;
}