#include <iostream>
using namespace std;

int set(int k) {
    int x;
    return x|(1<<k);
}