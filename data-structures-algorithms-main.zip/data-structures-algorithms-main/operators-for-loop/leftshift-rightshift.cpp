#include <iostream>
using namespace std;

int main() {
    cout<< (9>>2) <<endl;
    cout<< (8<<3) <<endl;

    return 0;
}