#include <iostream>
using namespace std;

int main() {
    int a = 4;
    int b = 7;

    cout<<a&b<<endl;
    cout<<a|b<<endl;
    cout<<~a<<endl;
    cout<<a^b<<endl;
}