#include <iostream>
using namespace std;

#define PI 3.14

int main() {
    cout<<PI*5*5 <<endl;
    return 0;
}