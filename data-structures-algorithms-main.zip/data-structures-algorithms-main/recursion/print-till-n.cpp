#include <iostream>
using namespace std;

void factorial(int n) {
    if(n == 0)
        return;
    print(n-1);
    cout<<n<<endl;
    
}